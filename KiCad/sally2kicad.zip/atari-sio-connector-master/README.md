# atari-sio-connector

Atari SIO connector (male socket pcb)
